package controller;


import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import model.Hotel;
import model.SnowHotel;
import model.SnowyVacation;
import model.Transportation;

public class SnowScreen5Controller 
{
	@FXML
	private TextField destTF = new TextField();
	
	
	@FXML
	private TextField travelTF = new TextField();
	
	@FXML
	private double travelCost, hotelCost, actsCost;
	
	@FXML
	private Double totalCost = new Double(0);
	
	@FXML
	private TextField hotelTF = new TextField();
	
	@FXML
	private TextField budgetTF = new TextField();
	
	@FXML
	private TextArea actsTA = new TextArea();
	
	public void populate(ActionEvent event)
	{
		destTF.setText(SnowyVacation.strDest);
		
		if (Transportation.transportType.equals("Drive"))
			travelTF.setText(Transportation.transportType+" - $"+Transportation.dRate+" x "+SnowyVacation.dDistanceFromSA+" miles");
		else
			travelTF.setText(Transportation.transportType+" - $"+Transportation.dRate+" x "+SnowyVacation.iTravelerNum+" Travelers");
		
		hotelTF.setText(SnowHotel.strName+" - $"+SnowHotel.dRate+" x "+SnowHotel.iDuration+" Days");
		
		
		for (String key: SnowyVacation.hmActivities.keySet())
		{
			actsTA.appendText(key+": $"+SnowyVacation.hmActivities.get(key)+"\n");
		}
		
		
		
		
	}
	
	public void calcBudget(ActionEvent event)
	{
		if (Transportation.transportType.equals("Drive"))
			travelCost = (Transportation.dRate * SnowyVacation.dDistanceFromSA);
		
		else
			travelCost = (Transportation.dRate * SnowyVacation.iTravelerNum);
		
		hotelCost = (SnowHotel.dRate * SnowHotel.iDuration);
		
		actsCost = 0;
		for (String key: SnowyVacation.hmActivities.keySet())
		{
			actsCost += SnowyVacation.hmActivities.get(key);
			
		}
		
		totalCost = (travelCost+hotelCost+actsCost);
		
		budgetTF.setText("$"+totalCost.toString());
	}
	
	
}
