package controller;

import java.io.IOException;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import model.Hotel;
import model.SnowHotel;

public class SnowScreen3CController 
{
	@FXML
	private TextField numDaysTF = new TextField();
	
	@FXML
	public String strDaysNum = new String();
	
	@FXML
	private AnchorPane mainPane = new AnchorPane();
	
	@FXML
	public void selectRate1(ActionEvent event)
	{
		SnowHotel.setName("Residence Inn");
		SnowHotel.setRate(188);
		
	}
	
	@FXML
	public void selectRate2(ActionEvent event)
	{
		SnowHotel.setName("Creekside Retreat");
		SnowHotel.setRate(320);
		
	}
	
	@FXML
	public void selectRate3(ActionEvent event)
	{
		SnowHotel.setName("Yellowstone Hotel");
		SnowHotel.setRate(501);
		
	}
	
	@FXML
	public void selectRate4(ActionEvent event)
	{
		SnowHotel.setName("Beaverhead Retreat");
		SnowHotel.setRate(275);
		
	}
	
	public void saveDaysNum()
	{
		strDaysNum = numDaysTF.getText();
		SnowHotel.setDuration(Integer.parseInt(strDaysNum));
		
	}
	
	@FXML
	public void goToScreen4(ActionEvent clickNextAE) 
	{
		saveDaysNum();
		
		try 
		{
			mainPane = (AnchorPane)FXMLLoader.load(getClass().getResource("/view/SnowScreen4.fxml"));
		} 
		
		catch (IOException e) 
		{
			e.printStackTrace();
		}
		
		Scene scene = new Scene(mainPane);
		Stage stageWindow = (Stage)((Node)clickNextAE.getSource()).getScene().getWindow();
		stageWindow.setScene(scene);
		stageWindow.show();
		
		
	}
	
	
	
}
