package controller;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.SelectionMode;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

/**
 * Controller class for Scene4.fxml(City).
 * It allows users to search and choose activities they'd like to do while on vacation. 
 * @author Maria Jose Healey(spb340)
 * @version 1.0
 */

public class Scene4Controller implements Initializable {
	private String userDestChoice;
	private String userHChoice;
	private String userFlightChoice;
	private ArrayList<String> userActivities;
	private int userVacationDays;
	private String userDepartureDate;
	private String userReturnDate;
	
	
	@FXML
    private AnchorPane cityScene4AP;
	
	/* Buttons */
    @FXML
    private Button startOverB;
    @FXML
    private Button Next;
    @FXML
    private Button searchActivitiesB;
    /* Label */
    @FXML
    private Label Title;
    /* ListView */
    @FXML
    private ListView<String> activitiesLV;
    
    /* handles the next Button */
	@FXML
	public void nextButtonPressed(ActionEvent event) throws IOException {
		userActivities= new ArrayList();
		
		/* items selected in the listView */
    	ObservableList listofItems=activitiesLV.getSelectionModel().getSelectedItems();
    	for(Object item : listofItems){
    		userActivities.add((String)item);
    	}
		
		/* communicating with scene5 */
		FXMLLoader loader=new FXMLLoader(getClass().getResource("/view/Scene5.fxml"));
		cityScene4AP= (AnchorPane)loader.load();
	    Scene5Controller scene5Controller= loader.getController();
	    scene5Controller.transferMessage(userDestChoice,userHChoice,userFlightChoice,userActivities,userDepartureDate,userReturnDate,userVacationDays);	        
	        
        Scene scene = new Scene(cityScene4AP);// pane you are GOING TO show
        Stage window = (Stage) ((Node)event.getSource()).getScene().getWindow();// pane you are ON
        window.setScene(scene);
        window.show();        
    	
	}
	
	/* handles the startOverB Button */
	@FXML
	public void handleStartOverB(ActionEvent event) throws IOException {
		Parent scene4 = FXMLLoader.load(getClass().getResource("/view/Scene2.fxml"));
		Scene scene4Scene = new Scene(scene4);
		Stage scene4Window = (Stage) ((Node) event.getSource()).getScene().getWindow();
		scene4Window.setScene(scene4Scene);
		scene4Window.show();
	}
	
	/* handles handleSearchActivitiesB Button*/
	@FXML
	public void handleSearchActivities(ActionEvent event) throws IOException {
		ArrayList<String> activities;
				
		/* loading activities ArrayList */				
		activities= new ArrayList();
		switch (userDestChoice){
		case "Las Vegas":
			activities.removeAll(activities);
			activities.add("Cirque do Soleil ,$299");
			activities.add("Hoover Dam ,$80");
			activities.add("Red Rock Canyon National Conservation Area ,$77.93");
			activities.add("SpeedVegas ,$149");
			activities.add("The Strip ,$69.99");
		    break;
		case "Miami":
			activities.removeAll(activities);
			activities.add("Crandon Park ,$5");
			activities.add("Little Havana ,$0");
			activities.add("Everglades National Park ,$149.95");
			activities.add("Bayside Marketplace ,$0");
			activities.add("Miami Beach ,$0");
		    break;
		case "New Orleans":
			activities.removeAll(activities);
			activities.add("French Quarter ,$0");
			activities.add("The National WWII Museum ,$29.77");
			activities.add("New Orleans Swamp Tours ,$59");
			activities.add("Mardi Gras World ,$22");
			activities.add("SteamBoat Natchez ,$38");
		    break;
		case "New York":
			activities.removeAll(activities);
			activities.add("Central Park ,$0");
			activities.add("American Museum of Natural History ,$23");
			activities.add("Statue of Liberty ,$19.25");
			activities.add("NYC Food Tours ,$240");
			activities.add("Broadway ,$216");
		    break;
		case "San Francisco":
			activities.removeAll(activities);
			activities.add("California Academy of Science ,$15");
			activities.add("Golden Gate Bridge ,$0");
			activities.add("Yerba Buena Gardens ,$0");
			activities.add("Twin Peaks ,$0");
			activities.add("Chinatown ,$63");
		    break;			       
		}
	
		/* displaying activities in the activitiesLV */
		activitiesLV.setVisible(true);
		for(String arrayListItems:activities){
			activitiesLV.getItems().add(arrayListItems);
		}
	}

	public void initialize(URL arg0, ResourceBundle arg1) {
		
		activitiesLV.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);
	}
	
	/* method to obtain userDestinationChoice,userHotelChoice ,flight,departureDate,returnDate and days from Scene3Controller */
    public void transferMessage(String userDestinationChoice, String userHotelChoice, String flight, int days,String departureDate,String returnDate){
    	userDestChoice=userDestinationChoice;
    	userHChoice=userHotelChoice;
    	userFlightChoice=flight;
    	userVacationDays=days;
    	userDepartureDate=departureDate;
    	userReturnDate=returnDate;
    }

}
