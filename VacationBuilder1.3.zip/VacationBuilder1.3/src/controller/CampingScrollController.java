package controller;

import java.io.IOException;
import java.math.BigDecimal;
import java.net.URL;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.ResourceBundle;

import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DateCell;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.text.Text;
import javafx.util.Callback;
import model.Hotel;
import model.Vacation;

public class CampingScrollController implements Initializable {
	@FXML
	private Label title;

	@FXML
	private DatePicker ReturnDate;
	@FXML
	private DatePicker DepartureDate;

	@FXML
	private ComboBox<Vacation> VacationDestCB;
	@FXML
	private ComboBox<Hotel> HotelCB;
	@FXML
	private ComboBox<String> HomeCityCB;

	@FXML
	private CheckBox op1CBx;
	@FXML
	private CheckBox op2CBx;
	@FXML
	private CheckBox op3CBx;
	@FXML
	private CheckBox op4CBx;
	@FXML
	private CheckBox op5CBx;
	@FXML
	private CheckBox op6CBx;
	@FXML
	private CheckBox op7CBx;
	@FXML
	private CheckBox op8CBx;
	@FXML
	private CheckBox op9CBx;
	@FXML
	private CheckBox op10CBx;

	@FXML
	private Button ExitButton;
	@FXML
	private Button FinalizeButton;

	@FXML
	private TextArea hotelTextArea;
	@FXML
	private TextArea Itinerary;
	@FXML
	private TextArea Bill;

	@FXML
	private ImageView imageView;

	@FXML
	private Text SumofActivities;
	@FXML
	private Text vacationDestError;
	@FXML
	private Text dateOOBerror;
	@FXML
	private Text hotelError;

	// closes app when pressed
	@FXML
	public void lastButtonPressed(ActionEvent event) throws IOException {
		Platform.exit();
	}

	// loads hotel options and all required information
	@FXML
	void hotelChoiceMade(ActionEvent event) {
		// gets user choice for hotel
		Hotel selectedHotel = HotelCB.getSelectionModel().getSelectedItem();
		// loads info of hotel from user choice
		switch (HotelCB.getSelectionModel().getSelectedIndex()) {
		case 0:
			hotelName = selectedHotel.getHotelName();
			hotelCost = selectedHotel.getHotelPrice();
			hotelTextArea.setText(selectedHotel.getHotelInfo());
			Image x0 = (new Image(
					getClass().getResourceAsStream("/pictures/" + selectedHotel.getHotelImage() + ".jpg")));
			imageView.setImage(x0);
			break;

		case 1:
			hotelName = selectedHotel.getHotelName();
			hotelCost = selectedHotel.getHotelPrice();
			hotelTextArea.setText(selectedHotel.getHotelInfo());
			Image x1 = (new Image(
					getClass().getResourceAsStream("/pictures/" + selectedHotel.getHotelImage() + ".jpg")));
			imageView.setImage(x1);
			break;

		case 2:
			hotelName = selectedHotel.getHotelName();
			hotelCost = selectedHotel.getHotelPrice();
			hotelTextArea.setText(selectedHotel.getHotelInfo());
			Image x2 = (new Image(
					getClass().getResourceAsStream("/pictures/" + selectedHotel.getHotelImage() + ".jpg")));
			imageView.setImage(x2);
			break;

		case 3:
			hotelName = selectedHotel.getHotelName();
			hotelCost = selectedHotel.getHotelPrice();
			hotelTextArea.setText(selectedHotel.getHotelInfo());
			Image x3 = (new Image(
					getClass().getResourceAsStream("/pictures/" + selectedHotel.getHotelImage() + ".jpg")));
			imageView.setImage(x3);
			break;

		case 4:
			hotelName = selectedHotel.getHotelName();
			hotelCost = selectedHotel.getHotelPrice();
			hotelTextArea.setText(selectedHotel.getHotelInfo());
			Image x4 = (new Image(
					getClass().getResourceAsStream("/pictures/" + selectedHotel.getHotelImage() + ".jpg")));
			imageView.setImage(x4);
			break;
		}
	}

	// gets user choice for vacation destination
	@FXML
	void vacationDestMade(ActionEvent event) {
		// clears hotel options so each vacation has there own
		HotelCB.getItems().removeAll(HotelCB.getItems());
		// clears hotels information from text box
		hotelTextArea.clear();
		// function call to disable all images
		imageView.setImage(x);
		// gets user choice for vacation destination
		Vacation selectedVacation = VacationDestCB.getSelectionModel().getSelectedItem();
		// once user picks destination then these hotel options will be loaded
		// to hotel ComboBox
		switch (VacationDestCB.getSelectionModel().getSelectedIndex()) {
		case 0:
			vacationSpot = selectedVacation.getVacName();
			flightCost = selectedVacation.getFlightPrice();
			HotelCB.setItems(FXCollections.observableArrayList(
					new Hotel("The St. Regis Aspen Resort", 350.99, 
							"Sitting on the southern edge of town, this beautiful hotel has added a modern spin\n"
									+ "on the traditional ski lodge, free airport shuttle to Aspen Airport available. \n"
									+ "St. Regis Aspen Resort wins travelers over with its full-service Rem�de Spa.", "St.Regis"),
					new Hotel("St. Julien Hotel & Spa	", 360.99, 
							" The majority of guests have nothing but good things to say about St Julien's\n"
									+ "spacious rooms which come stocked with a minibar, Italian linens, flat-screen TVs\n"
									+ "and complimentary wireless Internet access. Located in the heart of Boulder", "St.Julien"),
					new Hotel("The Ritz Carlton	", 400.99, 
							"Renovated in 2017 and sitting in downtown Denver, The Ritz-Carlton is surrounded by some of\n"
									+ "the city's top things to do. Recent guests love that it's just a short walk to Coors Field. \n"
									+ "Great location in the heart of downtown Denver. ", "RitzCarlton"),
					new Hotel("The Brown Palace Hotel", 275.99, 
							"Denver's landmark hotel is a hit with history buffs and luxury lovers alike.\n"
									+ "The Brown Palace Hotel in the Uptown neighborhood has catered to the city's\n"
									+ "visitors for more than 100 years, and recent guests praised the property's period\n"
									+ "accents and antiquated ambiance, as well as its premiere customer service. \n"
									+ "In fact, this lavish hotel may be a great choice for a couples getaway.", "BrownPalace"),
					new Hotel("Hotel Boulderado	", 230.99, 
							"The guest rooms and suites at the Hotel Boulderado, which come in a variety of styles and sizes, feature \n"
									+ "premium cable channels, Aveda bath products,bathrobes, spacious workstations and modern bathrooms with \n"
									+ "granite countertops. Recent guests enjoyed the variety of on-site eateries and the central downtown location", "HotelBoulderado")));
			break;
		case 1:
			vacationSpot = selectedVacation.getVacName();
			flightCost = selectedVacation.getFlightPrice();
			HotelCB.setItems(FXCollections.observableArrayList(
					new Hotel("Crystal Mountain Resort", 199.99, 
							"The sprawling expanse of the ski terrain flows over half a dozen peaks and basins and\n"
								+ "lends itself to seemingly limitless variations. Summer at Crystal Mountain features \n"
								+ "mountain-top dining with fresh Northwest cuisine, abundant wild flowers, hiking trails,\n"  
								+ "horseback rides, disc golf course and a wealth of wildlife and scenery.", "CrytsalMountain"),
						new Hotel("Willows Lodge		", 250.99, 
							"Check into our intimate, award-winning Woodinville hotel and experience the Northwest's greatest\n"
								+ "escape. The deep comfort of rooms and suites with fireplaces and soaking tubs, an award winning \n"
								+ "place. Here in Woodinville the colors seem richer, the air fresher, the food tastier.", "WillowsLodge"),
						new Hotel("Kalama Harbor Lodge Motel", 195.99, 
							"Built in 2018 with a nod to Kalama's Hawaiian heritage, this riverfront hotel is reminiscent of\n" 
								+ "Lahaina, Maui's classic Pioneer Inn. Inside guests will find hours of entertainment with art,\n" 
								+ " history, live music two nights a week, a pub, rooftop bar and a South Seas lounge.", "KalamaHarbor"),
						new Hotel("Crowne Plaza Hotel		", 200.99, 
							"Perfectly located in the heart of the Emerald City, the award-winning Crowne Plaza Hotel in downtown Seattle\n" 
								+ "offers an exceptional blend of cool, comfortable & unconventional touches that set us apart as soon as you\n"   
								+ "step inside. Our recently remodeled hotel embodies a warm and welcoming ambience found throughout our\n"
								+ "luxurious hotel. Enjoy an invigorating workout at our 24-hour fitness center.", "CrownePlaza"),
						new Hotel("Skykomish River Lodge", 150.99, 
							"Washington's Cascade Mountains, on the banks of the south fork of the Skykomish River, This L.L.C.\n"  
								+ "(Luxury Log Cabin) is a haven of sumptuous feather beds, gourmet kitchen, great room with \n" 
								+ "two-story rock fireplace, and a large deck perfect for relaxing and taking in the sights\n"
								+ " and sounds of the Skykomish River.", "Skykomish")));
			break;
		case 2:
			vacationSpot = selectedVacation.getVacName();
			flightCost = selectedVacation.getFlightPrice();
			HotelCB.setItems(FXCollections.observableArrayList(
					new Hotel("Amangiri		", 299.99, 
							"Sitting about a mile from the Arizona border in Canyon Point, Utah, Amangiri incorporates the\n"
								+ "surrounding landscape into its design. The hotel adopts the muted browns of the desert in its interior\n"
								+ "and its pool wraps around a sandstone butte. Recent guests enjoyed the property's breathtaking desert views.", "Amangiri"),
						new Hotel("The Grand America Hotel", 330.99, 
							"As the bigger sibling to the popular Little America Hotel, The Grand America Hotel leads the boutique\n"
								+ "pack in Salt Lake City. Visitors say the property offers the perfect blend of comfort and elegance", "GrandAmerica"),	
						new Hotel("Kimpton Hotel Monaco", 350.99, 
							"Like most Kimpton properties, the Hotel Monaco Salt Lake City appeals to trendy travelers. \n"
								+ "Guests appreciate this hotel's creative-yet-tasteful design, praising the guest rooms\n"
								+ "for their size and their wealth of amenities (including flat-screen TVs\n"
								+ "and Atelier Bloem luxury toiletries).", "KimptonMonaco"),
						new Hotel("Sundance Mountain Resort", 295.99, 
							"Sundance Mountain Resort sits in Sundance, Utah about 50 miles southeast of Salt Lake City,\n"
								+ "making it a great home base for those looking to explore the Wasatch Mountains. \n"
								+ "Both The Spa at Sundance and the Tree Room restaurant are devoted to sustainability\n"
								+ "relying on organic ingredients found locally.", "Sundance"),
						new Hotel("The Chateaux Deer Valley", 380.99, 
							"Rising out of Deer Valley Resort's Silver Lake Village, The Chateaux Deer Valley offers guests the \n"
								+ "quintessential ski lodge experience, complete with crackling fireplaces and winter sports equipment\n"
								+ "rentals. Guest rooms range from simple studios to multiroom villas, each equipped with a kitchenette or \n"
								+ "kitchen, complimentary wireless internet and carved wooden furnishings.", "DeerValley")));
			break;
		case 3:
			vacationSpot = selectedVacation.getVacName();
			flightCost = selectedVacation.getFlightPrice();
			HotelCB.setItems(FXCollections.observableArrayList(
					new Hotel("Canyon Ranch Tucson		", 450.99, 
							"This all-inclusive health resort and spa provides more than just a vacation, but a retreat. \n"
								+ "And guests say if you're looking for large helping of rejuvenation with a \n"
								+ " pinch of transformation, Canyon Ranch is the place to go.", "CanyonRanch"),
						new Hotel("Mountain Shadows		", 325.99, 
							"Mountain Shadows is a 4.5 star hotel located at 5445 E Lincoln Dr in Phoenix. \n"
								+ " It has a 5.0 overall guest rating based on 369 reviews.\n"
								+ "2 restaurants, 2 outdoor pools, and a golf course are available at this smoke-free hotel.", "MountainShadows"),
						new Hotel("Arizona Inn			", 150.99, 
							"Sprawled across 14 acres of verdant lawns and manicured gardens in central Tucson, Arizona, \n"
								+ " the Arizona Inn has been offering guests a taste of the Southwest since 1930.\n"
								+ "Accommodations offer at least 500 square feet of space", "ArizonaInn"),
						new Hotel("Andaz Scottsdale Resort & Bungalows", 255.99, 
							"Guests rave about the cuisine at this Scottsdale, Arizona outpost. \n"
								+ "You can also enjoy mountain views from one of three outdoor pools or from the fitness center", "AndazResort"),
						new Hotel("The Westin Kierland Villas		", 350.99, 
							"Overlooking the Kierland Golf Club in northern Scottsdale, \n"
								+ "The Westin Kierland Villas indulges lodgers looking for a little extra breathing room.\n"
								+ "These one- and two-bedroom accommodations come equipped with kitchenettes, dining areas, \n"
								+ " in-room laundry facilities and private patios or balconies.", "WestinVillas")));
			break;
		case 4:
			vacationSpot = selectedVacation.getVacName();
			flightCost = selectedVacation.getFlightPrice();
			HotelCB.setItems(FXCollections.observableArrayList(
					new Hotel("The Inn of the Five Graces		", 550.99, 
							"Unlike other hotels in Santa Fe, New Mexico, The Inn of the Five Graces does not try to\n"
								+ "steep you in Southwestern culture. Rather, guests here are transported to the Eastern Hemisphere: \n"
								+ "The decor includes imported treasures from the Middle East and Asia, including tapestries and mosaic tiles.", "GoodGraces"),
								
						new Hotel("Rosewood Inn of the Anasazi		", 318.99, 
							"Like all Rosewood properties, the Inn of the Anasazi marries detail-oriented customer service with\n"
								+ "luxury accommodations, prompting high praise from guests. Inspired by the natural beauty of\n"
								+ "New Mexico and the artistic designs of local Native American tribes, guest rooms are\n"
								+ "spacious and boast handcrafted beds and gas-lit fireplaces alongside contemporary amenities", "Anasazi"),
						new Hotel("La Fonda				", 305.99, 
							"Like many of the elite hotels in Santa Fe, La Fonda has a rich history. This landmark property has\n"
								+ "been welcoming Santa Fe visitors since the 1920s. And according to guests, the hotel has aged well.\n"
								+ "Many describe La Fonda as charming and enchanting.", "LaFonda"),
						new Hotel("Hotel Santa Fe, The Hacienda & Spa", 340.99, 
							"Hotel Santa Fe isn't your typical high-end hotel. \n"
								+ "Though it's quite removed from the Plaza, this is the only Native American-owned\n"
								+ "property in the city, meaning that you'll have access to cultural experiences\n"
								+ "like storytelling, teepee dining and tribal dancing. ", "SantaFeSpa"),
						new Hotel("Eldorado Hotel & Spa		", 375.99, 
							"To truly live it up in Santa Fe, New Mexico, recent guests recommend a stay at the Eldorado.\n"
								+ "Travelers are quick to note the impressive upgrades to the rooms, which garner praise for\n"
								+ "their authentic Southwestern decor, handcrafted furnishings and private verandas with adobe\n"
								+ "fireplaces. Complimentary Historic Santa Fe Plaza walking tours are available.", "Eldorado")));
			break;
		}
	}

	// sets all images to false, to make them not visible

	// CheckBoxes for activities each box has own price
	@FXML
	public void updateButtonPressed(ActionEvent event) throws IOException {
		double totalCost = 0.0;
		BigDecimal totalCostBD;
		if (op1CBx.isSelected()) {
			totalCost += 19.99;
		}
		if (op2CBx.isSelected()) {
			totalCost += 19.99;
		}
		if (op3CBx.isSelected()) {
			totalCost += 19.99;
		}
		if (op4CBx.isSelected()) {
			totalCost += 19.99;
		}
		if (op5CBx.isSelected()) {
			totalCost += 19.99;
		}
		if (op6CBx.isSelected()) {
			totalCost += 19.99;
		}
		if (op7CBx.isSelected()) {
			totalCost += 19.99;
		}
		if (op8CBx.isSelected()) {
			totalCost += 19.99;
		}
		if (op9CBx.isSelected()) {
			totalCost += 19.99;
		}
		if (op10CBx.isSelected()) {
			totalCost += 19.99;
		}
		// fixes floating decimals
		totalCostBD = truncateDecimal(totalCost);
		totalCostString = totalCostBD.toString();
		SumofActivities.setText("$" + totalCostString);
	}

	// makes the decimal only 2 spaces
	private static BigDecimal truncateDecimal(double x) {
		int numberofDecimals = 2;
		if (x > 0) {
			return new BigDecimal(String.valueOf(x)).setScale(numberofDecimals, BigDecimal.ROUND_FLOOR);
		} else {
			return new BigDecimal(String.valueOf(x)).setScale(numberofDecimals, BigDecimal.ROUND_CEILING);
		}
	}

	// does some error checking and if all is good, then updates bill and
	// itinerary
	@FXML
	public void finalizeButtonPressed(ActionEvent event) throws IOException {
		// calculations and conversions for the bill
		double activitiesCost = Double.parseDouble(totalCostString);

		BigDecimal hotelTotalBD = truncateDecimal(hotelCost * days);
		String hotelTotal = hotelTotalBD.toString();
		double hotelTotalCost = Double.parseDouble(hotelTotal);
		BigDecimal grandTotalBD = truncateDecimal((hotelCost * days) + activitiesCost + flightCost);
		grandTotal = grandTotalBD.toString();
		double grandTotalCost = Double.parseDouble(grandTotal);
		// sets error messages not visible
		vacationDestError.setVisible(false);
		dateOOBerror.setVisible(false);
		hotelError.setVisible(false);
		Bill.setText("");
		Itinerary.setText("");

		// error checking
		// makes sure they chose a vacation spot
		if (vacationSpotChosen())
			vacationDestError.setVisible(true);
		// makes sure they return date is after the departure date
		if (returnBeforeDep())
			dateOOBerror.setVisible(true);
		// makes sure they chose a vacation spot
		if (hotelChosen())
			hotelError.setVisible(true);
		// if no errors print the itinerary and bill
		if (hotelChosen() == false && returnBeforeDep() == false && vacationSpotChosen() == false) {
			// the itinerary set text area
			Bill.setText("\t\t     Receipt");
			Bill.appendText("\n\t   Cost                  Item Description");
			Bill.appendText(
					"\n\t$" + String.valueOf(hotelTotalCost) + "          " + hotelName + " for " + days + " nights");
			Bill.appendText("\n\t$" + String.valueOf(flightCost) + "          Roundtrip Flight to " + vacationSpot);
			Bill.appendText("\n\t$" + totalCostString + "          Packages Added");
			Bill.appendText("\n___________________________________________________");
			Bill.appendText("\n\t$" + String.valueOf(grandTotalCost) + "          Final Amount");

			Itinerary.setText("\t  " + (days + 1) + " Day Trip to " + vacationSpot);
			Itinerary.appendText("\nYou will be departing on " + formatter.format(DepartureDate.getValue()));
			Itinerary.appendText("\nYou will be returning on " + formatter.format(ReturnDate.getValue()));
			Itinerary.appendText("\nYou will be staying at " + hotelName);
		}
	}

	// error checking function
	public boolean vacationSpotChosen() {
		boolean picked = VacationDestCB.getSelectionModel().isEmpty();
		return picked;
	}

	// error checking function
	public boolean returnBeforeDep() {
		boolean gtg = false;
		days = (int) ChronoUnit.DAYS.between(DepartureDate.getValue(), ReturnDate.getValue());
		if (days < 0)
			gtg = true;
		return gtg;
	}

	// error checking function
	public boolean hotelChosen() {
		boolean picked = HotelCB.getSelectionModel().isEmpty();
		return picked;
	}

	// loads the calendars for users to pick dates
	public void calenderFunction() {
		final Callback<DatePicker, DateCell> dayCellFactory = new Callback<DatePicker, DateCell>() {
			public DateCell call(final DatePicker datePicker) {
				return new DateCell() {
					public void updateItem(LocalDate item, boolean empty) {
						super.updateItem(item, empty);
						if (item.isBefore(LocalDate.now())) {
							setDisable(true);
							setStyle("-fx-background-color: black;");
						}
					}
				};
			}
		};
		final Callback<DatePicker, DateCell> dayCellFactory1 = new Callback<DatePicker, DateCell>() {
			public DateCell call(final DatePicker datePicker) {
				return new DateCell() {
					public void updateItem(LocalDate item, boolean empty) {
						super.updateItem(item, empty);
						if (item.isBefore(DepartureDate.getValue().plusDays(1))) {
							setDisable(true);
							setStyle("-fx-background-color: #ffc0cb;");
						}
					}
				};
			}
		};

		DepartureDate.setDayCellFactory(dayCellFactory);
		DepartureDate.setValue(LocalDate.now());
		ReturnDate.setDayCellFactory(dayCellFactory1);
		ReturnDate.setValue(LocalDate.now().plusDays(3));

	}

	// Important variables used for filling in text
	String totalCostString = "0.00";
	String grandTotal = "";
	int days;
	String hotelName = "";
	String vacationSpot = "";
	double hotelCost = 0.00;
	double flightCost = 0.00;
	DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MMM dd, yyyy");
	Image x = (new Image(getClass().getResourceAsStream("/pictures/camping.jpg")));

	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		// sets starting location to san antonio like they all fly from there
		HomeCityCB.getItems().addAll("San Antonio, TX");
		HomeCityCB.setValue("San Antonio, TX");
		// loads the items into vacation options
		VacationDestCB.setItems(FXCollections.observableArrayList(
				// EXAMPLE new Vacation("Los Angeles, CA", 206.99)
				new Vacation("Colorado", 300.99), new Vacation("Washington", 150.99), new Vacation("Utah		", 250.99),
				new Vacation("Arizona	", 225.99), new Vacation("New Mexico", 200.99)));
		hotelTextArea.setEditable(false);
		Itinerary.setEditable(false);
		Bill.setEditable(false);
		calenderFunction();
		// calculates days of trip
		days = (int) ChronoUnit.DAYS.between(DepartureDate.getValue(), ReturnDate.getValue());
		imageView.setImage(x);
	}
}
