package model;

public class SnowHotel 
{
	public static String strName;
	public static double dRate;
	public static int iDuration;
	
	public static void setName(String strName)
	{
		SnowHotel.strName = strName;
		
	}
	
	public static void setRate(double dRate)
	{
		SnowHotel.dRate = dRate;
		
	}
	
	public static void setDuration(int iDuration)
	{
		SnowHotel.iDuration = iDuration;
		
	}
	
	
	
}
