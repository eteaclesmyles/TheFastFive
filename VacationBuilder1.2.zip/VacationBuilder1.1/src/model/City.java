package model;

import java.util.ArrayList;
import java.util.HashMap;

/**
 * Model class City. 
 * @author Maria Jose Healey(spb340)
 * @version 1.0
 */

public class City {
	private String cityName;
	private String hotel;
	private int days;
	private Flight flight; // departure date, return date, airline,price
	private ArrayList<String> actividades = new ArrayList();
	
	/* constructor */
	public City(String cityName,Flight flight, String hotel, ArrayList<String> actividades,int days) {
		this.cityName=cityName;
		this.flight = flight;
		this.hotel = hotel;
		this.actividades = actividades;
		this.days=days;
	}

	/* getters and setters */
	public String getCityName(){
		return cityName;
	}
	public void setCityName(String cityName){
		this.cityName=cityName;
	}
	public Flight getFlight() {
		return flight;
	}

	public void setFlight(Flight flight) {
		this.flight = flight;
	}

	public String getHotel() {
		return hotel;
	}

	public void setHotel(String hotel) {
		this.hotel = hotel;
	}

	public int getDays() {
		return days;
	}

	public void setDays(int days) {
		this.days = days;
	}
	
	public ArrayList<String> getActividades() {
		return actividades;
	}

	public void setActividades(ArrayList<String> actividades) {
		this.actividades = actividades;
	}
	
}
