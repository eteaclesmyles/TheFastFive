package controller;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import model.SnowyVacation;


public class SnowScreen1Controller {
	
	@FXML
	private AnchorPane mainPane;
	
	//@FXML
	//private ComboBox numTravCBox;
	
	//ObservableList<Integer> numTravList = FXCollections.observableArrayList(1,2,3,4,5,6,7,8,9,10); 
	
	@FXML
	private Button screen1NextButton;
	
	@FXML
	private RadioButton AspenCOButton, JackWYButton, SkyMTButton, ParkUTButton;
	
	@FXML
	private TextField numTravsTF = new TextField();
	
	@FXML
	public String strTravNum = new String();
	
	@FXML
	public void selectAspen(ActionEvent event)
	{
		//SnowyVacation snowVacation = new SnowyVacation();
		SnowyVacation.setDest("Aspen, Colorado");
	}
	
	@FXML
	public void selectJack(ActionEvent event)
	{
		//SnowyVacation snowVacation = new SnowyVacation();
		SnowyVacation.setDest("Jackson Hole, Wyoming");
	}
	
	@FXML
	public void selectSky(ActionEvent event)
	{
		//SnowyVacation snowVacation = new SnowyVacation();
		SnowyVacation.setDest("Big Sky, Montana");
	}
	
	@FXML
	public void selectPark(ActionEvent event)
	{
		//SnowyVacation snowVacation = new SnowyVacation();
		SnowyVacation.setDest("Park City, Utah");
	}
	
	@FXML
	public void goToScreen2(ActionEvent clickNextAE) 
	{
		saveTravNum();
		
		try 
		{
			mainPane = (AnchorPane)FXMLLoader.load(getClass().getResource("/view/SnowScreen2.fxml"));
		} 
		
		catch (IOException e) 
		{
			e.printStackTrace();
		}
		
		Scene scene = new Scene(mainPane);
		Stage stageWindow = (Stage)((Node)clickNextAE.getSource()).getScene().getWindow();
		stageWindow.setScene(scene);
		stageWindow.show();
		
		
	}

	public void saveTravNum()
	{
		strTravNum = numTravsTF.getText();
		SnowyVacation.setTravelNum(Integer.parseInt(strTravNum));
		//System.out.println(SnowyVacation.iTravelerNum);
		//System.out.println(SnowyVacation.strDest);
	}
	
	
	
	
	
	
	
}
