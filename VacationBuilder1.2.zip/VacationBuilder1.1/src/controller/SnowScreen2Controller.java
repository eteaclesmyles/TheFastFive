package controller;

import java.io.IOException;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import model.SnowyVacation;
import model.Transportation;

public class SnowScreen2Controller {

	@FXML
	private AnchorPane mainPane = new AnchorPane();
	
	@FXML
	private Button flightButton = new Button();
	
	@FXML
	private Button driveButton = new Button();
	
	@FXML
	private Button busButton = new Button();
	
	@FXML
	public void goToScreen3(ActionEvent clickNextAE) 
	{
		
		if (SnowyVacation.strDest.equals("Aspen, Colorado"))
		{
		
			try 
			{
				mainPane = (AnchorPane)FXMLLoader.load(getClass().getResource("/view/SnowScreen3HotelSetA.fxml"));
			} 
		
			catch (IOException e) 
			{
				e.printStackTrace();
			}
		
			Scene scene = new Scene(mainPane);
			Stage stageWindow = (Stage)((Node)clickNextAE.getSource()).getScene().getWindow();
			stageWindow.setScene(scene);
			stageWindow.show();
		
		}
		
		// Jackson WY
		
		else if (SnowyVacation.strDest.equals("Jackson Hole, Wyoming"))
		{
		
			try 
			{
				mainPane = (AnchorPane)FXMLLoader.load(getClass().getResource("/view/SnowScreen3HotelSetB.fxml"));
			} 
		
			catch (IOException e) 
			{
				e.printStackTrace();
			}
		
			Scene scene = new Scene(mainPane);
			Stage stageWindow = (Stage)((Node)clickNextAE.getSource()).getScene().getWindow();
			stageWindow.setScene(scene);
			stageWindow.show();
		
		}
		
		//Big Sky, MT
		
		else if (SnowyVacation.strDest.equals("Big Sky, Montana"))
		{
		
			try 
			{
				mainPane = (AnchorPane)FXMLLoader.load(getClass().getResource("/view/SnowScreen3HotelSetC.fxml"));
			} 
		
			catch (IOException e) 
			{
				e.printStackTrace();
			}
		
			Scene scene = new Scene(mainPane);
			Stage stageWindow = (Stage)((Node)clickNextAE.getSource()).getScene().getWindow();
			stageWindow.setScene(scene);
			stageWindow.show();
		
		}
		
		// Park City, Utah
		
		else if (SnowyVacation.strDest.equals("Park City, Utah"))
		{
		
			try 
			{
				mainPane = (AnchorPane)FXMLLoader.load(getClass().getResource("/view/SnowScreen3HotelSetD.fxml"));
			} 
		
			catch (IOException e) 
			{
				e.printStackTrace();
			}
		
			Scene scene = new Scene(mainPane);
			Stage stageWindow = (Stage)((Node)clickNextAE.getSource()).getScene().getWindow();
			stageWindow.setScene(scene);
			stageWindow.show();
		
		}
		
	}
	
	@FXML
	public void setFlightMode(ActionEvent event)
	{
		Transportation.transportType = "Flight";
		Transportation.dRate = 359;
		
	}
	
	@FXML
	public void setDriveMode(ActionEvent event)
	{
		Transportation.transportType = "Drive";
		Transportation.dRate = 0.16;
		
		if (SnowyVacation.strDest.equals("Aspen, Colorado"))
		{
			SnowyVacation.dDistanceFromSA = 1066;
		}
		
		else if (SnowyVacation.strDest.equals("Big Sky, Montana"))
		{
			SnowyVacation.dDistanceFromSA = 1659;
		}
		
		else if (SnowyVacation.strDest.equals("Park City, Utah"))
		{
			SnowyVacation.dDistanceFromSA = 1315;
		}
		
		else if (SnowyVacation.strDest.equals("Jackson Hole, Wyoming"))
		{
			SnowyVacation.dDistanceFromSA = 1420;
		}
		
	}
	
	@FXML
	public void setBusMode(ActionEvent event)
	{
		Transportation.transportType = "Bus";
		Transportation.dRate = 166;
		
	}
	
	
}
